/**
 * 
 */
/**
 * 
 */
module Tateti {
	requires org.junit.jupiter.api;
	requires java.desktop;
}
